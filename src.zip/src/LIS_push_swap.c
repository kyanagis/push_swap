#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

typedef struct  s_lisbuf
{
 int *tails;
 int *tidx;
 int *prev;
 int len;
} t_lisbuf;


static int binary_search(int *arr,int len,int key)
{
    int low;
    int high;
    int mid;

    low = 0;
    high = len;
    while(low < high)
    {
        mid = low + (high - low) / 2;
        if(arr[mid] < key)
            low = mid + 1;
        else
            high = mid ;
    }

        return low;
}

static void zero_keep(char *keep,int n)
{
    int i;
    i = 0;
    while(i < n){
    keep[i] = 0;
        ++i;
    }
}

static void reconstruct_lis(int len,int *tidx,int *prev,char *keep)
{
    int k;
    k = tidx[len - 1];
    while(k != -1)
    {
        keep[k] = 1;
        k = prev[k];

    }
}

static int	alloc_bufs(int n, t_lisbuf *b)
{
	b->tails = (int *)malloc(sizeof(int) * n);
	if (!b->tails)
		return (1);
	b->tidx = (int *)malloc(sizeof(int) * n);
	if (!b->tidx)
	{
		free(b->tails);
		return (1);
	}
	b->prev = (int *)malloc(sizeof(int) * n);
	if (!b->prev)
	{
		free(b->tails);
		free(b->tidx);
		return (1);
	}
	b->len = 0;
	return (0);
}

static void build_lis(const int *arr,int n,t_lisbuf *b)
{

        int i;
        int pos;
        i = 0;
        while(i < n)
        {
            pos = binary_search(b->tails,b->len,arr[i]);
            b->tails[pos] = arr[i];
            b->tidx[pos] = i;
            if(pos > 0)
                b->prev[i] = b->tidx[pos - 1];
            else
                b->prev[i] = -1;
            if(pos == b->len)
                ++(b->len);
                ++i;
        }
}

int mark_lis(const int *arr,int n,char *keep)
{
t_lisbuf b;
    if(n <= 0)
        return 0;
    if(alloc_bufs(n,&b))
        return -1;

	build_lis(arr, n, &b);
	zero_keep(keep, n);
	reconstruct_lis(b.len, b.tidx, b.prev, keep);
	free(b.tails);
	free(b.tidx);
	free(b.prev);
	return (b.len);
}


int	main(void)
{
	int  a[] = {1, 3, 5, 2, 4, 6};
	int  n = sizeof(a) / sizeof(a[0]);
	char keep[6];
	int  len;
	int  i;

	len = mark_lis(a, n, keep);
	i = 0;
	while (i < n)
	{
		printf("%d: %d keep=%d\n", i, a[i], keep[i]);
		++i;
	}
	printf("LIS len = %d\n", len);
	return (0);
}